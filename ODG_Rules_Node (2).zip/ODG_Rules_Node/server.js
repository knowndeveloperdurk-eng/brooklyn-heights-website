const express = require("express");
const path = require("path");
const compression = require("compression");
const helmet = require("helmet");

const app = express();
const PORT = process.env.PORT || 3001;

app.disable("x-powered-by");

app.use(
  helmet({
    contentSecurityPolicy: false
  })
);

app.use(compression());

app.use(
  express.static(path.join(__dirname, "public"), {
    maxAge: process.env.NODE_ENV === "production" ? "1d" : 0,
    etag: true
  })
);

app.get("/health", (req, res) => {
  res.status(200).json({
    ok: true,
    service: "Brooklyn Heights Rules",
    uptime: Math.floor(process.uptime())
  });
});

// Express 5 / path-to-regexp compatible SPA fallback.
// Do NOT use app.get("*") in Express 5.
app.use((req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("");
  console.log("======================================");
  console.log("     BROOKLYN HEIGHTS RULES WEBSITE");
  console.log("======================================");
  console.log(` Local:   http://localhost:${PORT}`);
  console.log(` Health:  http://localhost:${PORT}/health`);
  console.log("======================================");
  console.log("");
});
