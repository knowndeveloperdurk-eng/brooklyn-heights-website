# ODG Rules Website — Node/Express

## Requirements
- Node.js 18+

## Run locally

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

## Development mode

```bash
npm run dev
```

## Custom port

Windows CMD:

```bat
set PORT=8080 && npm start
```

PowerShell:

```powershell
$env:PORT=8080; npm start
```

Linux/VPS:

```bash
PORT=8080 npm start
```

## Production/VPS

A process manager such as PM2 can keep the site running:

```bash
npm install -g pm2
pm2 start server.js --name odg-rules
pm2 save
```

The server listens on `0.0.0.0` and honors the host's `PORT` environment variable.

## Project structure

```text
ODG_Rules_Node/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── server.js
├── package.json
├── .env.example
└── .gitignore
```
