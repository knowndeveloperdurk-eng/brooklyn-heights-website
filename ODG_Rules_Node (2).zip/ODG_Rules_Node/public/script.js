const body = document.body;
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const themeLabel = document.querySelector('.theme-label');
const sidebar = document.getElementById('sidebar');
const mobileMenu = document.getElementById('mobileMenu');
const navItems = [...document.querySelectorAll('.nav-item')];
const sections = [...document.querySelectorAll('.rule-section')];

const savedTheme = localStorage.getItem('bh-theme');
body.classList.remove('light');
syncTheme();

function syncTheme(){
  const light = body.classList.contains('light');
  themeIcon.textContent = light ? '☀' : '☾';
  themeLabel.textContent = light ? 'Light mode' : 'Dark mode';
}
themeToggle.addEventListener('click',()=>{
  body.classList.toggle('light');
  localStorage.setItem('bh-theme', body.classList.contains('light') ? 'light' : 'dark');
  syncTheme();
});

mobileMenu.addEventListener('click',()=>sidebar.classList.toggle('open'));
navItems.forEach(a=>a.addEventListener('click',()=>sidebar.classList.remove('open')));

const observer = new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      navItems.forEach(n=>n.classList.toggle('active', n.getAttribute('href') === '#'+entry.target.id));
    }
  })
},{rootMargin:'-25% 0px -65% 0px'});
sections.forEach(s=>observer.observe(s));

const overlay = document.getElementById('searchOverlay');
const openSearch = document.getElementById('searchButton');
const closeSearch = document.getElementById('closeSearch');
const searchInput = document.getElementById('searchInput');
const results = document.getElementById('searchResults');

function showSearch(){
  overlay.classList.add('open');
  overlay.setAttribute('aria-hidden','false');
  setTimeout(()=>searchInput.focus(),30);
}
function hideSearch(){
  overlay.classList.remove('open');
  overlay.setAttribute('aria-hidden','true');
  searchInput.value='';
  results.innerHTML='<p class="search-hint">Start typing to search rules and guidelines.</p>';
}
openSearch.addEventListener('click',showSearch);
closeSearch.addEventListener('click',hideSearch);
overlay.addEventListener('click',e=>{if(e.target===overlay)hideSearch()});
document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();showSearch()}
  if(e.key==='Escape') hideSearch();
});

searchInput.addEventListener('input',()=>{
  const q = searchInput.value.trim().toLowerCase();
  if(!q){results.innerHTML='<p class="search-hint">Start typing to search rules and guidelines.</p>';return;}
  const matches=sections.filter(s=>s.innerText.toLowerCase().includes(q));
  if(!matches.length){results.innerHTML='<p class="search-hint">No matching BH rules found.</p>';return;}
  results.innerHTML=matches.map(s=>{
    const text=s.innerText.replace(/\s+/g,' ').trim();
    const pos=text.toLowerCase().indexOf(q);
    const snippet=text.slice(Math.max(0,pos-45),Math.min(text.length,pos+115));
    return `<a class="search-result" href="#${s.id}" data-close><b>${s.dataset.title}</b><span>…${snippet}…</span></a>`;
  }).join('');
  results.querySelectorAll('[data-close]').forEach(a=>a.addEventListener('click',hideSearch));
});
